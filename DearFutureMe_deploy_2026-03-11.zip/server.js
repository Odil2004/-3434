const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const { sql } = require("@vercel/postgres");

require("dotenv").config();

const app = express();
const rootDir = __dirname;
const dataDir = path.join(rootDir, "data");
const dataFile = path.join(dataDir, "store.json");
const port = Number(process.env.PORT || 3000);
const jwtSecret = process.env.JWT_SECRET || "change-this-secret";
const jobSecret = process.env.JOB_SECRET || "change-this-job-secret";
const promoAdminSecret = process.env.PROMO_ADMIN_SECRET || "change-this-promo-secret";
const appBaseUrl = process.env.APP_BASE_URL || `http://localhost:${port}`;
if (process.env.DATABASE_URL && !process.env.POSTGRES_URL) {
  process.env.POSTGRES_URL = process.env.DATABASE_URL;
}
const useDatabase = Boolean(process.env.POSTGRES_URL);
const defaultStore = { users: [], capsules: [], pendingRegistrations: [], pendingPasswordResets: [], promoCodes: [] };
let storeReady = false;

app.use(express.json({ limit: "20mb" }));
app.use(express.static(rootDir));

async function ensureStore() {
  if (storeReady) return;
  if (useDatabase) {
    await sql`CREATE TABLE IF NOT EXISTS dfm_store (id int primary key, data jsonb not null)`;
    const existing = await sql`SELECT id FROM dfm_store WHERE id = 1`;
    if (existing.rowCount === 0) {
      await sql`INSERT INTO dfm_store (id, data) VALUES (1, ${defaultStore})`;
    }
    storeReady = true;
    return;
  }
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(defaultStore, null, 2), "utf8");
  }
  storeReady = true;
}

async function readStore() {
  await ensureStore();
  if (useDatabase) {
    const result = await sql`SELECT data FROM dfm_store WHERE id = 1`;
    const store = result.rows[0]?.data || { ...defaultStore };
    if (!Array.isArray(store.users)) store.users = [];
    if (!Array.isArray(store.capsules)) store.capsules = [];
    if (!Array.isArray(store.pendingRegistrations)) store.pendingRegistrations = [];
    if (!Array.isArray(store.pendingPasswordResets)) store.pendingPasswordResets = [];
    if (!Array.isArray(store.promoCodes)) store.promoCodes = [];
    return store;
  }
  const raw = fs.readFileSync(dataFile, "utf8").replace(/^\uFEFF/, "");
  const store = JSON.parse(raw);
  if (!Array.isArray(store.users)) store.users = [];
  if (!Array.isArray(store.capsules)) store.capsules = [];
  if (!Array.isArray(store.pendingRegistrations)) store.pendingRegistrations = [];
  if (!Array.isArray(store.pendingPasswordResets)) store.pendingPasswordResets = [];
  if (!Array.isArray(store.promoCodes)) store.promoCodes = [];
  return store;
}

async function writeStore(store) {
  await ensureStore();
  if (useDatabase) {
    await sql`UPDATE dfm_store SET data = ${store} WHERE id = 1`;
    return;
  }
  fs.writeFileSync(dataFile, JSON.stringify(store, null, 2), "utf8");
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function isValidUserName(name) {
  return /^[A-Za-z][A-Za-z0-9_]{2,19}$/.test(String(name || ""));
}

function getAdminEmails() {
  return Array.from(
    new Set(
      [
        process.env.SMTP_USER,
        "dearfuturemeportal@gmail.com",
        ...(String(process.env.ADMIN_EMAILS || "")
          .split(",")
          .map((value) => value.trim())
          .filter(Boolean))
      ]
        .map((value) => normalizeEmail(value))
        .filter(Boolean)
    )
  );
}

function isAdminEmail(email) {
  const normalized = normalizeEmail(email);
  return getAdminEmails().includes(normalized);
}

function isPlaceholderCity(city) {
  const value = String(city || "").trim().toLowerCase();
  return !value || [
    "your city",
    "ваш город",
    "deine stadt",
    "tu ciudad",
    "votre ville"
  ].includes(value);
}

function publicUser(user) {
  const premiumUntil = user.premiumUntil || null;
  const isPremium = premiumUntil ? new Date(premiumUntil).getTime() > Date.now() : false;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt: user.createdAt,
    plan: isPremium ? "premium" : "free",
    premiumUntil,
    premiumSource: user.premiumSource || null,
    isAdmin: isAdminEmail(user.email)
  };
}

function hasActivePremium(user) {
  return !!user && !!user.premiumUntil && new Date(user.premiumUntil).getTime() > Date.now();
}

function addMonths(date, months) {
  const next = new Date(date);
  next.setMonth(next.getMonth() + months);
  return next;
}

function analyzeEmotion(text) {
  const s = String(text || "").toLowerCase();
  const set = [
    { id: "love", label: "Love", color: "#d96c8f", k: ["love", "любов", "сердц", "люблю", "обнима", "семь"] },
    { id: "hope", label: "Hope", color: "#c4933f", k: ["hope", "надеж", "верю", "мечта", "мечт"] },
    { id: "fear", label: "Fear", color: "#7f7f9a", k: ["fear", "страх", "бою", "паник", "ужас"] },
    { id: "joy", label: "Joy", color: "#e8c97a", k: ["joy", "счаст", "радост", "улыб"] },
    { id: "dream", label: "Dreams", color: "#6aa57a", k: ["dream", "goal", "цель", "достиг", "план"] }
  ];
  for (const d of set) {
    if (d.k.some((k) => s.includes(k))) return d;
  }
  return { id: "calm", label: "Calm", color: "#8a7f6f" };
}

const EMOJI_SET = new Set([
  "✨",
  "❤️",
  "😊",
  "😌",
  "🌿",
  "😨",
  "🚀",
  "🔥",
  "🌙",
  "🌊"
]);

function isValidEmoji(value) {
  if (!value) return true;
  return EMOJI_SET.has(value);
}

function generateScene(text) {
  const year = new Date().getFullYear() + 10;
  const places = ["by the sea", "in a quiet city", "in the mountains", "in a warm room"];
  const idx = Math.abs(String(text || "").length) % places.length;
  return `${year} year. You are ${places[idx]} and reading your letter.`;
}

function buildPromoCode(duration) {
  const prefix = duration === "year" ? "DFM-Y" : "DFM-M";
  return `${prefix}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
}

function promoDurationMonths(duration) {
  return duration === "year" ? 12 : 1;
}

function promoDurationLabel(duration) {
  return duration === "year" ? "1 year" : "1 month";
}

function adminPromoRequired(req, res, next) {
  if ((req.headers["x-admin-secret"] || "") !== promoAdminSecret) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

function adminRequired(req, res, next) {
  if (!req.user || !isAdminEmail(req.user.email)) {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
}

function issueToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email, name: user.name },
    jwtSecret,
    { expiresIn: "30d" }
  );
}

async function authRequired(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ")
    ? authHeader.slice(7)
    : null;
  if (!token) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const payload = jwt.verify(token, jwtSecret);
    const store = await readStore();
    const user = store.users.find((entry) => entry.id === payload.sub);
    if (!user) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

function serializeCapsule(capsule) {
  return {
    id: capsule.id,
    userId: capsule.userId,
    name: capsule.name,
    email: capsule.email,
    message: capsule.message,
    openDate: capsule.openDate,
    visibility: capsule.visibility,
    prediction: capsule.prediction,
    style: capsule.style || "classic",
    photoUrl: capsule.photoUrl || null,
    videoUrl: capsule.videoUrl || null,
    audioUrl: capsule.audioUrl || null,
    hunt: !!capsule.hunt,
    secret: !!capsule.secretHash,
    emoji: capsule.emoji || null,
    emotion: capsule.emotion || null,
    futureScene: capsule.futureScene || null,
    createdAt: capsule.createdAt,
    city: capsule.city,
    lat: capsule.lat,
    lng: capsule.lng,
    deliveredAt: capsule.deliveredAt || null
  };
}

function serializePublicCapsule(capsule) {
  return {
    id: capsule.id,
    userId: capsule.userId,
    name: capsule.name,
    message: capsule.secretHash ? "" : capsule.message,
    openDate: capsule.openDate,
    prediction: capsule.prediction,
    style: capsule.style || "classic",
    photoUrl: capsule.photoUrl || null,
    videoUrl: capsule.videoUrl || null,
    audioUrl: capsule.audioUrl || null,
    hunt: !!capsule.hunt,
    secret: !!capsule.secretHash,
    emoji: capsule.emoji || null,
    emotion: capsule.emotion || null,
    futureScene: capsule.futureScene || null,
    createdAt: capsule.createdAt,
    city: capsule.city,
    lat: capsule.lat,
    lng: capsule.lng
  };
}

function isHttpUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

function isValidPhotoUrl(value) {
  if (!value) return true;
  if (value.startsWith("data:image/")) {
    return value.length <= 800000;
  }
  return isHttpUrl(value);
}

function isValidVideoUrl(value) {
  if (!value) return true;
  if (value.startsWith("data:video/")) {
    return value.length <= 12000000;
  }
  return isHttpUrl(value);
}

function isValidAudioUrl(value) {
  if (!value) return true;
  if (value.startsWith("data:audio/")) {
    return value.length <= 6000000;
  }
  return isHttpUrl(value);
}

function getStats(store) {
  const delivered = store.capsules.filter((capsule) => capsule.deliveredAt).length;
  return {
    sealed: store.capsules.length,
    countries: 0,
    delivered,
    users: store.users.length
  };
}

function getTransporter() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    return null;
  }

  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || "false") === "true",
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

function cleanupPendingRegistrations(store) {
  const now = Date.now();
  store.pendingRegistrations = store.pendingRegistrations.filter((entry) => {
    return new Date(entry.expiresAt).getTime() > now;
  });
}

function cleanupPendingPasswordResets(store) {
  const now = Date.now();
  store.pendingPasswordResets = store.pendingPasswordResets.filter((entry) => {
    return new Date(entry.expiresAt).getTime() > now;
  });
}

function buildVerificationCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function hashVerificationCode(code) {
  return crypto.createHash("sha256").update(String(code)).digest("hex");
}

async function sendVerificationCodeEmail({ email, name, code }) {
  const transporter = getTransporter();
  if (!transporter) {
    return { delivered: false, reason: "smtp_not_configured" };
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: email,
      subject: "Welcome to DearFutureMe - confirm your account",
      text: [
        `Hello, ${name}.`,
        "",
        "Welcome to DearFutureMe.",
        "You are almost done creating your account.",
        "",
        "Use this verification code to confirm your registration:",
        "",
        code,
        "",
        "The code expires in 10 minutes.",
        "",
        "Write to your future self. Seal your capsule. Let time deliver it."
      ].join("\n"),
      html: `
        <div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#201810">
          <h2 style="margin:0 0 16px">Welcome to DearFutureMe</h2>
          <p>Hello, <strong>${escapeHtml(name)}</strong>.</p>
          <p>Thank you for creating an account on <strong>DearFutureMe</strong>.</p>
          <p>Use this verification code to confirm your registration:</p>
          <div style="margin:24px 0;padding:18px 20px;background:#f7f1e7;border:1px solid #e2c488;font-size:32px;letter-spacing:10px;text-align:center;font-weight:bold;color:#8d6422;">
            ${escapeHtml(code)}
          </div>
          <p>The code expires in 10 minutes.</p>
          <p style="margin-top:20px;color:#5a4a36">Write to your future self. Seal your capsule. Let time deliver it.</p>
        </div>
      `
    });

    return { delivered: true, reason: null };
  } catch (error) {
    return { delivered: false, reason: `smtp_failed:${error.message}` };
  }
}

async function sendPasswordResetEmail({ email, name, code }) {
  const transporter = getTransporter();
  if (!transporter) {
    return { delivered: false, reason: "smtp_not_configured" };
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: email,
      subject: "DearFutureMe - password reset code",
      text: [
        `Hello, ${name || "friend"}.`,
        "",
        "We received a request to reset your password.",
        "Use this 6-digit code to set a new password:",
        "",
        code,
        "",
        "If you did not request this, you can ignore this email.",
        "",
        "DearFutureMe"
      ].join("\n")
    });

    return { delivered: true };
  } catch (error) {
    return { delivered: false, reason: error.message };
  }
}

async function sendWelcomeEmail({ email, name }) {
  const transporter = getTransporter();
  if (!transporter) {
    return { delivered: false, reason: "smtp_not_configured" };
  }

  try {
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: email,
      subject: "Welcome - your DearFutureMe account is ready",
      text: [
        `Hello, ${name}.`,
        "",
        "Your DearFutureMe account has been successfully created.",
        "",
        "Now you can:",
        "- write your first capsule",
        "- save private or public messages",
        "- open your profile and track your capsules",
        "",
        `Open the site: ${appBaseUrl}`
      ].join("\n"),
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:24px;color:#201810">
          <h2 style="margin:0 0 16px">Your DearFutureMe account is ready</h2>
          <p>Hello, <strong>${escapeHtml(name)}</strong>.</p>
          <p>You have successfully registered on <strong>DearFutureMe</strong>.</p>
          <p>Now you can write your first capsule, save public or private messages, and manage everything from your profile.</p>
          <p style="margin-top:24px"><a href="${escapeAttribute(appBaseUrl)}" style="display:inline-block;padding:12px 18px;background:#c4933f;color:#1a1410;text-decoration:none">Open DearFutureMe</a></p>
        </div>
      `
    });

    return { delivered: true, reason: null };
  } catch (error) {
    return { delivered: false, reason: `smtp_failed:${error.message}` };
  }
}

async function deliverDueCapsules() {
  const transporter = getTransporter();
  if (!transporter) {
    return { sent: 0, pending: 0, skipped: "smtp_not_configured" };
  }

  const now = Date.now();
  const store = await readStore();
  const due = store.capsules.filter((capsule) => {
    if (capsule.deliveredAt) {
      return false;
    }
    return new Date(capsule.openDate).getTime() <= now;
  });

  let sent = 0;

  for (const capsule of due) {
    if (!isCapsuleAllowed({ message: capsule.message, prediction: capsule.prediction })) {
      continue;
    }

    const openDate = new Date(capsule.openDate).toLocaleString("ru-RU");
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: capsule.email,
      subject: "Your DearFutureMe capsule is ready",
      text: [
        `Hello, ${capsule.name}.`,
        "",
        `Your capsule opened on ${openDate}.`,
        "",
        capsule.message,
        "",
        capsule.prediction ? `AI reflection: ${capsule.prediction}` : "",
        "",
        `Open the site: ${appBaseUrl}`
      ]
        .filter(Boolean)
        .join("\n"),
      html: `
        <div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#201810">
          <h2 style="margin:0 0 16px">Your DearFutureMe capsule is ready</h2>
          <p>Hello, <strong>${escapeHtml(capsule.name)}</strong>.</p>
          <p>Your capsule opened on <strong>${escapeHtml(openDate)}</strong>.</p>
          <blockquote style="margin:24px 0;padding:16px 18px;border-left:4px solid #c4933f;background:#f7f1e7">
            ${escapeHtml(capsule.message).replace(/\n/g, "<br>")}
          </blockquote>
          ${
            capsule.prediction
              ? `<p><strong>AI reflection:</strong> ${escapeHtml(capsule.prediction)}</p>`
              : ""
          }
          <p><a href="${escapeAttribute(appBaseUrl)}">Open DearFutureMe</a></p>
        </div>
      `
    });

    capsule.deliveredAt = new Date().toISOString();
    sent += 1;
  }

  if (sent > 0) {
    await writeStore(store);
  }

  return { sent, pending: due.length - sent, skipped: null };
}

function getUtcDateKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

function formatDaysRu(days) {
  const mod10 = days % 10;
  const mod100 = days % 100;
  if (mod10 === 1 && mod100 !== 11) return `${days} день`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${days} дня`;
  return `${days} дней`;
}

function getDaysLeft(openDate) {
  const diff = new Date(openDate).getTime() - Date.now();
  if (!Number.isFinite(diff)) return null;
  return Math.max(0, Math.ceil(diff / 86400000));
}

async function sendDailyReminders() {
  const transporter = getTransporter();
  if (!transporter) {
    return { sent: 0, pending: 0, skipped: "smtp_not_configured" };
  }

  const now = Date.now();
  const todayKey = getUtcDateKey();
  const store = await readStore();
  const pending = store.capsules.filter((capsule) => {
    if (capsule.deliveredAt) return false;
    return new Date(capsule.openDate).getTime() > now;
  });

  let sent = 0;
  for (const capsule of pending) {
    if (capsule.reminderLastSent === todayKey) continue;
    const daysLeft = getDaysLeft(capsule.openDate);
    if (!daysLeft || daysLeft <= 0) continue;

    const openDate = new Date(capsule.openDate).toLocaleDateString("ru-RU");
    const daysLabel = formatDaysRu(daysLeft);

    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: capsule.email,
      subject: `Напоминание DearFutureMe — осталось ${daysLabel}`,
      text: [
        `Здравствуйте, ${capsule.name}.`,
        "",
        `До открытия вашей капсулы осталось ${daysLabel}.`,
        `Дата открытия: ${openDate}.`,
        "",
        `Открыть сайт: ${appBaseUrl}`
      ].join("\n"),
      html: `
        <div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto;padding:24px;color:#201810">
          <h2 style="margin:0 0 16px">Напоминание DearFutureMe</h2>
          <p>Здравствуйте, <strong>${escapeHtml(capsule.name)}</strong>.</p>
          <p>До открытия вашей капсулы осталось <strong>${escapeHtml(daysLabel)}</strong>.</p>
          <p>Дата открытия: <strong>${escapeHtml(openDate)}</strong>.</p>
          <p style="margin-top:24px"><a href="${escapeAttribute(appBaseUrl)}">Открыть DearFutureMe</a></p>
        </div>
      `
    });

    capsule.reminderLastSent = todayKey;
    sent += 1;
  }

  if (sent > 0) {
    await writeStore(store);
  }

  return { sent, pending: pending.length - sent, skipped: null };
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeAttribute(value) {
  return escapeHtml(value);
}

const ABUSE_PATTERNS = [
  /\b(kill|murder|shoot|stab|bomb|explode|terror|hostage|massacre|attack|assassinat)\b/i,
  /\b(threat|blackmail|extort|ransom)\b/i,
  /\b(suicide bombing|school shooting|pipe bomb)\b/i,
  /(убью|убить|взорв|бомб|теракт|заложник|расстрел|зареж|шантаж|вымогат|угроз)/i,
  /(взорвать|нападу|сожгу|убьем|убью вас)/i,
  /(мчс|сбу|полици|прокуратур|военком|посольств|правительств|госорган)/i
];

function findAbuseMatch(text) {
  const value = String(text || "");
  return ABUSE_PATTERNS.find((pattern) => pattern.test(value)) || null;
}

function isCapsuleAllowed({ message, prediction }) {
  return !findAbuseMatch(message) && !findAbuseMatch(prediction);
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.get("/api/stats", async (_req, res) => {
  const store = await readStore();
  res.json(getStats(store));
});

app.post("/api/auth/request-code", async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = normalizeEmail(req.body.email);
  const password = String(req.body.password || "");

  if (!name || !email || password.length < 6 || !isValidUserName(name)) {
    return res.status(400).json({ error: "Invalid registration payload" });
  }

  const store = await readStore();
  cleanupPendingRegistrations(store);
  const exists = store.users.find((user) => user.email === email);
  if (exists) {
    return res.status(409).json({ error: "User already exists" });
  }

  const code = buildVerificationCode();
  const passwordHash = await bcrypt.hash(password, 10);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const existingPending = store.pendingRegistrations.find((entry) => entry.email === email);
  const pending = {
    id: existingPending?.id || crypto.randomUUID(),
    name,
    email,
    passwordHash,
    codeHash: hashVerificationCode(code),
    expiresAt,
    createdAt: existingPending?.createdAt || new Date().toISOString()
  };

  store.pendingRegistrations = store.pendingRegistrations.filter((entry) => entry.email !== email);
  store.pendingRegistrations.push(pending);
  await writeStore(store);

  const emailResult = await sendVerificationCodeEmail({ email, name, code });
  const payload = {
    ok: true,
    expiresAt,
    emailSent: emailResult.delivered
  };
  if (!emailResult.delivered) {
    payload.verificationCode = code;
    payload.note = emailResult.reason;
  }

  res.status(200).json(payload);
});

app.post("/api/auth/register", async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const code = String(req.body.code || "").trim();

  if (!email || !code) {
    return res.status(400).json({ error: "Invalid verification payload" });
  }

  const store = await readStore();
  cleanupPendingRegistrations(store);
  const pending = store.pendingRegistrations.find((entry) => entry.email === email);
  if (!pending) {
    await writeStore(store);
    return res.status(400).json({ error: "Verification code expired or missing" });
  }

  if (pending.codeHash !== hashVerificationCode(code)) {
    return res.status(400).json({ error: "Invalid verification code" });
  }

  const user = {
    id: crypto.randomUUID(),
    name: pending.name,
    email: pending.email,
    passwordHash: pending.passwordHash,
    createdAt: new Date().toISOString(),
    premiumUntil: null,
    premiumSource: null
  };

  store.pendingRegistrations = store.pendingRegistrations.filter((entry) => entry.email !== email);
  store.users.push(user);
  await writeStore(store);
  await sendWelcomeEmail({ email: user.email, name: user.name });

  res.status(201).json({
    token: issueToken(user),
    user: publicUser(user)
  });
});

app.post("/api/auth/login", async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const password = String(req.body.password || "");
  const store = await readStore();
  const user = store.users.find((entry) => entry.email === email);

  if (!user) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const validPassword = await bcrypt.compare(password, user.passwordHash);
  if (!validPassword) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  res.json({
    token: issueToken(user),
    user: publicUser(user)
  });
});

app.post("/api/auth/request-reset", async (req, res) => {
  const email = normalizeEmail(req.body.email);
  if (!email) {
    return res.status(400).json({ error: "Invalid email" });
  }

  const store = await readStore();
  cleanupPendingPasswordResets(store);
  const user = store.users.find((entry) => entry.email === email);
  if (!user) {
    await writeStore(store);
    return res.status(404).json({ error: "User not found" });
  }

  const code = buildVerificationCode();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const existing = store.pendingPasswordResets.find((entry) => entry.email === email);
  const pending = {
    id: existing?.id || crypto.randomUUID(),
    email,
    codeHash: hashVerificationCode(code),
    expiresAt,
    createdAt: existing?.createdAt || new Date().toISOString()
  };

  store.pendingPasswordResets = store.pendingPasswordResets.filter((entry) => entry.email !== email);
  store.pendingPasswordResets.push(pending);
  await writeStore(store);

  const emailResult = await sendPasswordResetEmail({ email, name: user.name, code });
  const payload = {
    ok: true,
    expiresAt,
    emailSent: emailResult.delivered
  };
  if (!emailResult.delivered) {
    payload.resetCode = code;
    payload.note = emailResult.reason;
  }

  res.status(200).json(payload);
});

app.post("/api/auth/reset-password", async (req, res) => {
  const email = normalizeEmail(req.body.email);
  const code = String(req.body.code || "").trim();
  const password = String(req.body.password || "");

  if (!email || !code || password.length < 6) {
    return res.status(400).json({ error: "Invalid reset payload" });
  }

  const store = await readStore();
  cleanupPendingPasswordResets(store);
  const pending = store.pendingPasswordResets.find((entry) => entry.email === email);
  if (!pending) {
    await writeStore(store);
    return res.status(400).json({ error: "Reset code expired or missing" });
  }

  if (pending.codeHash !== hashVerificationCode(code)) {
    return res.status(400).json({ error: "Invalid reset code" });
  }

  const user = store.users.find((entry) => entry.email === email);
  if (!user) {
    await writeStore(store);
    return res.status(404).json({ error: "User not found" });
  }

  user.passwordHash = await bcrypt.hash(password, 10);
  store.pendingPasswordResets = store.pendingPasswordResets.filter((entry) => entry.email !== email);
  await writeStore(store);

  res.json({ ok: true });
});

app.get("/api/auth/me", authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.get("/api/admin/stats", authRequired, adminRequired, async (req, res) => {
  const store = await readStore();
  const stats = getStats(store);
  const publicCapsules = store.capsules.filter((capsule) => capsule.visibility === "public").length;
  const premiumUsers = store.users.filter((user) => user.premiumUntil && new Date(user.premiumUntil).getTime() > Date.now()).length;
  const unusedPromoCodes = store.promoCodes.filter((promo) => !promo.usedBy && !promo.disabledAt).length;
  res.json({
    users: store.users.length,
    premiumUsers,
    publicCapsules,
    sealed: stats.sealed,
    delivered: stats.delivered,
    unusedPromoCodes
  });
});

app.post("/api/admin/promo/generate", authRequired, adminRequired, (req, res) => {
  const duration = String(req.body.duration || "month").trim().toLowerCase();
  if (!["month", "year"].includes(duration)) {
    return res.status(400).json({ error: "Invalid promo duration" });
  }

  const store = await readStore();
  const promo = {
    id: crypto.randomUUID(),
    code: buildPromoCode(duration),
    duration,
    createdAt: new Date().toISOString(),
    usedBy: null,
    usedAt: null,
    disabledAt: null,
    disabledBy: null
  };
  store.promoCodes.push(promo);
  await writeStore(store);

  res.status(201).json({
    promo: {
      code: promo.code,
      duration: promo.duration,
      durationLabel: promoDurationLabel(promo.duration)
    }
  });
});

app.post("/api/promo/activate", authRequired, async (req, res) => {
  const code = String(req.body.code || "").trim().toUpperCase();
  if (!code) {
    return res.status(400).json({ error: "Promo code is required" });
  }

  const store = await readStore();
  const promo = store.promoCodes.find((entry) => entry.code === code);
  if (!promo) {
    return res.status(404).json({ error: "Promo code not found" });
  }
  if (promo.disabledAt) {
    return res.status(409).json({ error: "Promo code is disabled" });
  }
  if (promo.usedBy) {
    return res.status(409).json({ error: "Promo code already used" });
  }

  const user = store.users.find((entry) => entry.id === req.user.id);
  if (!user) {
    return res.status(404).json({ error: "User not found" });
  }

  const startDate = user.premiumUntil && new Date(user.premiumUntil).getTime() > Date.now()
    ? new Date(user.premiumUntil)
    : new Date();
  const premiumUntil = addMonths(startDate, promoDurationMonths(promo.duration)).toISOString();

  user.premiumUntil = premiumUntil;
  user.premiumSource = `promo:${promo.code}`;
  promo.usedBy = user.id;
  promo.usedAt = new Date().toISOString();
  await writeStore(store);

  res.json({
    ok: true,
    duration: promo.duration,
    durationLabel: promoDurationLabel(promo.duration),
    user: publicUser(user)
  });
});

app.post("/api/admin/promo/disable", authRequired, adminRequired, async (req, res) => {
  const code = String(req.body.code || "").trim().toUpperCase();
  if (!code) {
    return res.status(400).json({ error: "Promo code is required" });
  }

  const store = await readStore();
  const promo = store.promoCodes.find((entry) => entry.code === code);
  if (!promo) {
    return res.status(404).json({ error: "Promo code not found" });
  }
  if (promo.usedBy) {
    return res.status(409).json({ error: "Promo code already used" });
  }
  if (promo.disabledAt) {
    return res.status(409).json({ error: "Promo code already disabled" });
  }

  promo.disabledAt = new Date().toISOString();
  promo.disabledBy = req.user.id;
  await writeStore(store);

  res.json({ ok: true, code });
});

app.get("/api/capsules", authRequired, async (req, res) => {
  const store = await readStore();
  const capsules = store.capsules
    .filter((capsule) => capsule.userId === req.user.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .map(serializeCapsule);

  res.json({ capsules });
});

app.get("/api/public-capsules", async (_req, res) => {
  const store = await readStore();
  const capsules = store.capsules
    .filter((capsule) => capsule.visibility === "public")
    .map(serializePublicCapsule);

  res.json({ capsules });
});

app.post("/api/capsules/sync-location", authRequired, async (req, res) => {
  const city = String(req.body.city || "").trim();
  const lat = Number(req.body.lat);
  const lng = Number(req.body.lng);

  if (!city || !Number.isFinite(lat) || !Number.isFinite(lng)) {
    return res.status(400).json({ error: "Invalid location payload" });
  }

  const store = await readStore();
  let updated = 0;
  store.capsules = store.capsules.map((capsule) => {
    if (capsule.userId !== req.user.id) return capsule;
    if (!isPlaceholderCity(capsule.city) && Number.isFinite(Number(capsule.lat)) && Number.isFinite(Number(capsule.lng)) && Number(capsule.lat) !== 0 && Number(capsule.lng) !== 0) {
      return capsule;
    }
    updated += 1;
    return {
      ...capsule,
      city,
      lat,
      lng
    };
  });
  await writeStore(store);

  res.json({ updated });
});

app.post("/api/capsules", authRequired, async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = normalizeEmail(req.body.email);
  const message = String(req.body.message || "").trim();
  const openDate = String(req.body.openDate || "");
  const visibility = req.body.visibility === "private" ? "private" : "public";
  const prediction = req.body.prediction ? String(req.body.prediction) : null;
  const style = String(req.body.style || "classic").trim().toLowerCase();
  const photoUrl = req.body.photoUrl ? String(req.body.photoUrl).trim() : "";
  const videoUrl = req.body.videoUrl ? String(req.body.videoUrl).trim() : "";
  const audioUrl = req.body.audioUrl ? String(req.body.audioUrl).trim() : "";
  const emoji = req.body.emoji ? String(req.body.emoji).trim() : "";
  const secret = Boolean(req.body.secret);
  const secretPassword = req.body.secretPassword ? String(req.body.secretPassword) : "";
  const hunt = Boolean(req.body.hunt);
  const city = String(req.body.city || "").trim() || "Your City";
  const lat = Number(req.body.lat);
  const lng = Number(req.body.lng);

  if (!name || !email || !message || Number.isNaN(new Date(openDate).getTime())) {
    return res.status(400).json({ error: "Invalid capsule payload" });
  }

  if (email !== req.user.email) {
    return res.status(400).json({ error: "Capsule email must match the account email" });
  }

  if (message.length > 5000) {
    return res.status(400).json({ error: "Message is too long" });
  }

  const store = await readStore();
  const currentUser = store.users.find((entry) => entry.id === req.user.id);
  if (!currentUser) {
    return res.status(404).json({ error: "User not found" });
  }
  if (!hasActivePremium(currentUser)) {
    const yearAgo = Date.now() - 365 * 24 * 60 * 60 * 1000;
    const recentCapsules = store.capsules.filter((capsule) => {
      return capsule.userId === req.user.id && new Date(capsule.createdAt).getTime() >= yearAgo;
    }).length;
    if (recentCapsules >= 3) {
      return res.status(403).json({ error: "Free plan limit reached: 3 capsules per year. Activate Premium to continue." });
    }
    if (photoUrl || videoUrl) {
      return res.status(403).json({ error: "Premium required to attach photo or video" });
    }
    if (audioUrl) {
      return res.status(403).json({ error: "Premium required to attach voice message" });
    }
    if (secret) {
      return res.status(403).json({ error: "Premium required to protect a capsule with a password" });
    }
    if (hunt) {
      return res.status(403).json({ error: "Premium required for Secret Capsule Hunt" });
    }
    if (style && style !== "classic") {
      return res.status(403).json({ error: "Premium required for capsule styles" });
    }
  }

  if (!isValidPhotoUrl(photoUrl) || !isValidVideoUrl(videoUrl) || !isValidAudioUrl(audioUrl)) {
    return res.status(400).json({ error: "Invalid media link" });
  }
  if (!isValidEmoji(emoji)) {
    return res.status(400).json({ error: "Invalid emoji selection" });
  }
  const allowedStyles = new Set(["classic", "gold", "emerald", "noir"]);
  if (!allowedStyles.has(style)) {
    return res.status(400).json({ error: "Invalid capsule style" });
  }
  if (hunt && visibility !== "public") {
    return res.status(400).json({ error: "Secret Capsule Hunt requires public visibility" });
  }
  if (hunt && secret) {
    return res.status(400).json({ error: "Secret Capsule Hunt cannot be combined with secret capsules" });
  }
  if (secret && String(secretPassword || "").length < 4) {
    return res.status(400).json({ error: "Secret password must be at least 4 characters" });
  }

  const secretHash = secret ? await bcrypt.hash(secretPassword, 10) : null;

  if (!isCapsuleAllowed({ message, prediction })) {
    return res.status(400).json({ error: "Unsafe or abusive content is not allowed" });
  }

  const capsule = {
    id: crypto.randomUUID(),
    userId: req.user.id,
    name,
    email,
    message,
    openDate,
    visibility,
    prediction,
    style,
    photoUrl: photoUrl || null,
    videoUrl: videoUrl || null,
    audioUrl: audioUrl || null,
    hunt,
    secretHash,
    emoji: emoji || null,
    emotion: null,
    futureScene: null,
    createdAt: new Date().toISOString(),
    city,
    lat: Number.isFinite(lat) ? lat : 0,
    lng: Number.isFinite(lng) ? lng : 0,
    deliveredAt: null
  };

  store.capsules.push(capsule);
  await writeStore(store);

  res.status(201).json({ capsule: serializeCapsule(capsule) });
});

app.post("/api/capsules/open", authRequired, async (req, res) => {
  const id = String(req.body.id || "").trim();
  const password = String(req.body.password || "");
  if (!id) {
    return res.status(400).json({ error: "Capsule id is required" });
  }

  const store = await readStore();
  const capsule = store.capsules.find((entry) => entry.id === id);
  if (!capsule) {
    return res.status(404).json({ error: "Capsule not found" });
  }

  const isOwner = capsule.userId === req.user.id;
  const isPublic = capsule.visibility === "public";
  const openReady = new Date(capsule.openDate || 0).getTime() <= Date.now();

  if (!isPublic && !isOwner) {
    return res.status(403).json({ error: "Access denied" });
  }

  if (capsule.secretHash) {
    if (!isOwner) {
      return res.status(403).json({ error: "Secret capsule can only be opened by the author" });
    }
    if (!openReady) {
      return res.status(403).json({ error: "Capsule is not open yet" });
    }
    if (!password) {
      return res.status(400).json({ error: "Password is required" });
    }
    const ok = await bcrypt.compare(password, capsule.secretHash);
    if (!ok) {
      return res.status(401).json({ error: "Invalid password" });
    }
  } else if (isOwner) {
    return res.status(403).json({ error: "Own capsule is locked" });
  } else if (!isPublic && !openReady) {
    return res.status(403).json({ error: "Capsule is not open yet" });
  }

  res.json({ capsule: serializeCapsule(capsule) });
});

function isAuthorizedJob(req) {
  if (req.headers["x-job-secret"] === jobSecret) {
    return true;
  }
  if (process.env.VERCEL && req.headers["x-vercel-cron"] === "1") {
    return true;
  }
  return false;
}

app.post("/api/jobs/send-due-capsules", async (req, res) => {
  if (!isAuthorizedJob(req)) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const result = await deliverDueCapsules();
  res.json(result);
});

app.post("/api/jobs/send-daily-reminders", async (req, res) => {
  if (!isAuthorizedJob(req)) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const result = await sendDailyReminders();
  res.json(result);
});

app.get("/api/jobs/send-due-capsules", async (req, res) => {
  if (!isAuthorizedJob(req)) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const result = await deliverDueCapsules();
  res.json(result);
});

app.get("/api/jobs/send-daily-reminders", async (req, res) => {
  if (!isAuthorizedJob(req)) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const result = await sendDailyReminders();
  res.json(result);
});

app.get("/", (_req, res) => {
  res.sendFile(path.join(rootDir, "index.html"));
});

app.get("/index.html", (_req, res) => {
  res.sendFile(path.join(rootDir, "index.html"));
});

app.get("/admin", (_req, res) => {
  res.sendFile(path.join(rootDir, "index.html"));
});

app.get("/i18n.extra.js", (_req, res) => {
  res.sendFile(path.join(rootDir, "i18n.extra.js"));
});

app.get("/seal-sound.mp3", (_req, res) => {
  res.sendFile(path.join(rootDir, "_ui_window_close_menu_screen_03_normal.mp3"));
});

app.get("/hammer-sound.mp3", (_req, res) => {
  res.sendFile(path.join(rootDir, "0be1c1022f8ed63.mp3"));
});

app.get("/windy-sound-effects.mp3", (_req, res) => {
  res.sendFile(path.join(rootDir, "windy-sound-effects.mp3"));
});

app.get("/favicon.ico", (_req, res) => {
  res.status(204).end();
});

if (!process.env.VERCEL) {
  ensureStore().catch((error) => {
    console.error("Store init failed:", error.message);
  });

  app.listen(port, () => {
    console.log(`DearFutureMe server running at ${appBaseUrl}`);
  });

  setInterval(() => {
    deliverDueCapsules().catch((error) => {
      console.error("Email delivery failed:", error.message);
    });
  }, 60000);

  setInterval(() => {
    sendDailyReminders().catch((error) => {
      console.error("Reminder delivery failed:", error.message);
    });
  }, 3600000);
}

module.exports = app;
